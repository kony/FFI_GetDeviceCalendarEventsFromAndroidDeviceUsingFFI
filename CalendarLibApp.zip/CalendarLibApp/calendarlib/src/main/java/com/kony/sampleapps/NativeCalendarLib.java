package com.kony.sampleapps;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Vector;

import  com.konylabs.android.*;


/**
 * The NativeCalendarLib is the library that can be used from a Kony application
 * to get the calendar events from the android device calendar. The methods of this
 * library can  be used by defining the FFI mappings inside a Kony application
 *
 *
 */
public class NativeCalendarLib  {

    private static String TAG_FFILIB = "FFI_Library";

    /**The method getAllEvents is called from the Kony application using FFI
     *
     * @return Vector of vectors each containing string type of data
     */
    public  static Vector<Vector<String>> getAllEvents() {

        //Get the application context using the Kony library
        Context context = KonyMain.getAppContext();
        if (context == null) {
            Log.d(TAG_FFILIB,"Context is returned as NULL");
            return null;
        }

        //Use content resolver to get the calendar events
        Cursor cursor = context.getContentResolver().query(Uri.parse("content://com.android.calendar/events"), new String[]{"calendar_id", "title", "description", "dtstart", "dtend", "eventLocation"}, null, null, null);


        Vector<Vector<String>> higlLvlVector = new Vector<Vector<String>>();

        if (cursor == null) {
            return null;
        } else {



            //Populate all the events into the vector of vectors containing strings. As Kony FFI supports only vectors, vector of vectors or primitive types,
            // we are populating the events into vector of vectors. Each vector holds the string type of data
            int curCount = cursor.getCount();
            Log.d(TAG_FFILIB,"Cursor returned "+ curCount+ " rows");
            if(curCount == 0){
                return null;
            }
            int ind = 0;
            cursor.moveToFirst();
            while (ind < cursor.getCount()) {
                Vector<String> innerVector = new Vector<String>();

                //Extract the column values
                String evtTitle = cursor.getString(cursor.getColumnIndex(CalendarContract.Events.TITLE));
                Log.d(TAG_FFILIB,"evtTitle: "+evtTitle);

                String calId = cursor.getString(cursor.getColumnIndex(CalendarContract.Events.CALENDAR_ID));
                Log.d(TAG_FFILIB,"calId: "+calId);

                Long startDateInMillisec = Long.parseLong(cursor.getString(cursor.getColumnIndex(CalendarContract.Events.DTSTART)));
                String startdateStr = getDate(startDateInMillisec);
                Log.d(TAG_FFILIB,"startdateStr: "+startdateStr);

                Long endDateInMillisec = Long.parseLong(cursor.getString(cursor.getColumnIndex(CalendarContract.Events.DTEND)));
                String enddateStr = getDate(endDateInMillisec);
                Log.d(TAG_FFILIB,"enddateStr: "+enddateStr);

                String evtLocation = cursor.getString(cursor.getColumnIndex(CalendarContract.Events.EVENT_LOCATION));
                Log.d(TAG_FFILIB,"evtLocation: "+evtLocation);


                //populate the values into the vector
                innerVector.addElement(evtTitle);
                innerVector.addElement(calId);
                innerVector.addElement(startdateStr);
                innerVector.addElement(enddateStr);
                innerVector.addElement(evtLocation);

                higlLvlVector.addElement(innerVector);
                cursor.moveToNext();
                ind++;
            }
            cursor.close();
            return higlLvlVector;
        }
    }
        public  static Vector<Vector<String>> getEventsFor(Vector<String> datecomponents) {
            Log.d(TAG_FFILIB,"Entered into the method: getEventsFor()");
            String dd = datecomponents.get(0);
            String mm = datecomponents.get(1);
            String yyyy = datecomponents.get(2);
            Log.d(TAG_FFILIB,"Params recvd - Day:"+dd+" Month:"+mm+" Year:"+yyyy);

            Calendar cal = Calendar.getInstance();
            cal.set(Integer.parseInt(yyyy),Integer.parseInt(mm)-1,Integer.parseInt(dd),0,0,0);

            long selectedDateInMilliSec = cal.getTimeInMillis();
            Log.d(TAG_FFILIB,"selectedDateInMilliSec:"+selectedDateInMilliSec);
            long oneDayMillisec = 86400000;
            long nextDayStartMilliSec = selectedDateInMilliSec+oneDayMillisec;
            Log.d(TAG_FFILIB,"nextDayStartMilliSec:"+nextDayStartMilliSec);

            //Get the application context using the Kony library
            Context context = KonyMain.getAppContext();
            if (context == null) {
                Log.d(TAG_FFILIB,"Context is returned as NULL");
                return null;
            }

            //Use content resolver to get the calendar events
            //Cursor cursor = context.getContentResolver().query(Uri.parse("content://com.android.calendar/events"), new String[]{"calendar_id", "title", "description", "dtstart", "dtend", "eventLocation"}, null, null, null);
            //String selectionClause = "(dtstart >= ? AND dtend <= ?) OR (dtstart >= ? AND allDay = ?)";
            String selectionClause = "(dtstart >= ? AND dtstart <= ? AND (deleted != 1))";

            String[] selectionsArgs = new String[]{"" + selectedDateInMilliSec, "" + nextDayStartMilliSec};

            Cursor cursor = context.getContentResolver().query(Uri.parse("content://com.android.calendar/events"), new String[]{"calendar_id", "title", "description", "dtstart", "dtend", "eventLocation"}, selectionClause, selectionsArgs, null);

            Vector<Vector<String>> higlLvlVector = new Vector<Vector<String>>();

            if (cursor == null) {
                return null;
            } else {

                int curCount = cursor.getCount();
                Log.d(TAG_FFILIB,"Cursor returned "+ curCount+ " rows");
                if(curCount == 0){
                    return null;
                }
                int ind = 0;
                cursor.moveToFirst();

                //Populate all the events into the vector of vectors containing strings. As Kony FFI supports only vectors, vector of vectors or primitive types,
                // we are populating the events into vector of vectors. Each vector holds the string type of data
                while (ind < cursor.getCount()) {
                    Vector<String> innerVector = new Vector<String>();

                    //Extract the column values
                    String evtTitle = cursor.getString(cursor.getColumnIndex(CalendarContract.Events.TITLE));
                    Log.d(TAG_FFILIB,"evtTitle: "+evtTitle);

                    String calId = cursor.getString(cursor.getColumnIndex(CalendarContract.Events.CALENDAR_ID));
                    Log.d(TAG_FFILIB,"calId: "+calId);

                    Long startDateInMillisec = Long.parseLong(cursor.getString(cursor.getColumnIndex(CalendarContract.Events.DTSTART)));
                    String startdateStr = getDate(startDateInMillisec);
                    Log.d(TAG_FFILIB,"startDateInMillisec: "+startDateInMillisec);
                    Log.d(TAG_FFILIB,"startdateStr: "+startdateStr);


                    Long endDateInMillisec = Long.parseLong(cursor.getString(cursor.getColumnIndex(CalendarContract.Events.DTEND)));
                    String enddateStr = getDate(endDateInMillisec);
                    Log.d(TAG_FFILIB,"endDateInMillisec: "+endDateInMillisec);
                    Log.d(TAG_FFILIB,"enddateStr: "+enddateStr);

                    String evtLocation = cursor.getString(cursor.getColumnIndex(CalendarContract.Events.EVENT_LOCATION));
                    Log.d(TAG_FFILIB,"evtLocation: "+evtLocation);

                    //populate the values into the vector
                    innerVector.addElement(evtTitle);
                    innerVector.addElement(calId);
                    innerVector.addElement(startdateStr);
                    innerVector.addElement(enddateStr);
                    innerVector.addElement(evtLocation);

                    higlLvlVector.addElement(innerVector);
                    cursor.moveToNext();
                    ind++;
                }
                cursor.close();
                return higlLvlVector;
            }
    }

    /** The getDate methods returns the string in dd/MM/yyyy hh:mm:ss AM/PM format
     * for a given value in millisec
     *
     * @param milliSeconds
     * @return The string in dd/MM/yyyy hh:mm:ss AM/PM format
     */
    private static String getDate(long milliSeconds) {
        SimpleDateFormat formatter = new SimpleDateFormat(
                "dd/MM/yyyy hh:mm:ss a");
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return formatter.format(calendar.getTime());
    }

}


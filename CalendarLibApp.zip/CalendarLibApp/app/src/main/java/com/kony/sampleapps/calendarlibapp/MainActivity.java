package com.kony.sampleapps.calendarlibapp;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.kony.sampleapps.NativeCalendarLib;
import com.kony.sampleapps.calendarlib.*;

import java.util.Vector;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*setContentView(R.layout.activity_main);

        TextView tv = (TextView) findViewById(R.id.textView);
        Vector<String> vc = new Vector<String>(3);
        vc.setSize(3);
        vc.set(0,"15");

        vc.set(1,"3");
        vc.set(2,"2016");

        tv.setText(NativeCalendarLib.getEventsFor(vc,this).get(0).get(1));*/
    }
}

function AS_Form_a4e7a702f26a4bed8d43ee3f783d5506(eventobject) {
    return showEventsForSelectedDate.call(this);
}
function AS_Button_e9027611aa1346e3b0a5d3cdbd6233ac(eventobject) {
    return invokeFFI.call(this);
}
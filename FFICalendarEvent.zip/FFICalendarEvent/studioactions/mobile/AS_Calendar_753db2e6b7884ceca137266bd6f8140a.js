function AS_Calendar_753db2e6b7884ceca137266bd6f8140a(eventobject, isValidDateSelected) {
    return showEventsForSelectedDate.call(this);
}
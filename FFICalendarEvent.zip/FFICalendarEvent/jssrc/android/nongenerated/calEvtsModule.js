function invokeFFI() {
    var returnedArr = NativeCalendar.konyGetCalEvents();
    //alert(JSON.stringify(returnedArr));
    var segData = [];
    for (var ind = 0; ind < returnedArr.length; ind++) {
        var eventTitle = returnedArr[ind][0]; //Title is returned at index 0
        var eventId = returnedArr[ind][1]; //Event id is at index 1
        var eventStartTime = returnedArr[ind][2]; //Event start time is at index 2
        var eventEndTime = returnedArr[ind][3]; //Event end time is at index 3
        var eventLocation = returnedArr[ind][4]; //Event location is at index 4
        segData.push({
            lblEvtTitle: eventTitle,
            lblEvtStartTime: "Start Time: " + eventStartTime,
            lblEvtEndTime: "End Time: " + eventEndTime
        });
    }
    frmHome.segCalEvts.setData(segData);
}

function showEventsForSelectedDate() {
    var calSelDateComp = frmCalendar.calEvt.dateComponents;
    var selectedDate = [calSelDateComp[0].toString(), calSelDateComp[1].toString(), calSelDateComp[2].toString()];
    var returnedArr = NativeCalendar.konyGetCalEventsFor(selectedDate);
    //alert(JSON.stringify(returnedArr));
    var segData = [];
    if (returnedArr == null) {
        segData.push({
            lblTitle: "No Events"
        });
        frmCalendar.segCalEvtsForGridView.setData(segData);
        return;
    }
    for (ind = 0; ind < returnedArr.length; ind++) {
        var eventTitle = returnedArr[ind][0]; //Title is returned at index 0
        var eventId = returnedArr[ind][1]; //Event id is at index 1
        var eventStartTimeStr = returnedArr[ind][2]; //Event start time is at index 2
        var eventStartTime = eventStartTimeStr.split(" ")[1];
        var ampmStr = eventStartTimeStr.split(" ")[2];
        var eventStartTimeHrMinPart = eventStartTime.split(":")[0] + ":" + eventStartTime.split(":")[1] + " " + ampmStr;
        var eventEndTimeStr = returnedArr[ind][3]; //Event end time is at index 3
        var eventEndTime = eventEndTimeStr.split(" ")[1];
        ampmStr = eventEndTimeStr.split(" ")[2];
        var eventEndTimeHrMinPart = eventEndTime.split(":")[0] + ":" + eventEndTime.split(":")[1] + " " + ampmStr;
        var eventLocation = returnedArr[ind][4]; //Event location is at index 4 
        segData.push({
            lblTitle: eventTitle,
            lblStartTime: eventStartTimeHrMinPart,
            lblEndTime: eventEndTimeHrMinPart,
            lblLocation: eventLocation
        });
    }
    frmCalendar.segCalEvtsForGridView.setData(segData);
    return;
}
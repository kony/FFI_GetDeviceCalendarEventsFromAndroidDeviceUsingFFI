//startup.js file
var globalhttpheaders = {};
var appConfig = {
    appId: "FFICalendarEvent",
    appName: "FFICalendarEvent",
    appVersion: "1.0.0",
    platformVersion: null,
    serverIp: "10.37.129.2",
    serverPort: "80",
    secureServerPort: "443",
    isDebug: true,
    middlewareContext: "FFICalendarEvent",
    isMFApp: false,
    eventTypes: ["FormEntry", "ServiceRequest", "Error", "Crash"],
    url: "http://e2equality.kitspl.com:8080/FFICalendarEvent/MWServlet",
    secureurl: "http://e2equality.kitspl.com:8080/FFICalendarEvent/MWServlet"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    initializesegTemCalEventsForGridView();
    initializetemplateSegmenCalEvts();
    frmCalendarGlobals();
    frmHomeGlobals();
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        marginsIncludedInWidgetContainerWeight: true,
        APILevel: 7000
    })
};

function themeCallBack() {
    callAppMenu();
    initializeGlobalVariables();
    kony.application.setApplicationInitializationEvents({
        preappinit: AS_AppEvents_1651682981e8449c81a9a1f4307bd08c,
        init: appInit,
        showstartupform: function() {
            frmCalendar.show();
        }
    });
};

function loadResources() {
    globalhttpheaders = {};
    kony.os.loadLibrary({
        "javaclassname": "com.konylabs.ffi.N_NativeCalendar"
    });
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        "eventTypes": appConfig.eventTypes,
    }
    kony.setupsdks(sdkInitConfig, onSuccessSDKCallBack, onSuccessSDKCallBack);
};

function onSuccessSDKCallBack() {
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}
kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
//If default locale is specified. This is set even before any other app life cycle event is called.
loadResources();
// If you wish to debug Application Initialization events, now is the time to
// place breakpoints.
debugger;
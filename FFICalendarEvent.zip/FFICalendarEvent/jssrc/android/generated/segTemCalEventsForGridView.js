function initializesegTemCalEventsForGridView() {
    FlexContainer0866fa824cb7e4b = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "40%",
        "id": "FlexContainer0866fa824cb7e4b",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "0dp",
        "skin": "CopyslFbox085de8fda99e84c",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    FlexContainer0866fa824cb7e4b.setDefaultUnit(kony.flex.DP);
    var FlexContainer05615ddcd057444 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "FlexContainer05615ddcd057444",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "40%"
    }, {}, {});
    FlexContainer05615ddcd057444.setDefaultUnit(kony.flex.DP);
    var lblStartTime = new kony.ui.Label({
        "height": "60%",
        "id": "lblStartTime",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0488ffe2f334442",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblEndTime = new kony.ui.Label({
        "height": "40%",
        "id": "lblEndTime",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0a38507c2b4574f",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    FlexContainer05615ddcd057444.add(
    lblStartTime, lblEndTime);
    var FlexContainer0f7cb8d372dce42 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "FlexContainer0f7cb8d372dce42",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "60%",
        "zIndex": 1
    }, {}, {});
    FlexContainer0f7cb8d372dce42.setDefaultUnit(kony.flex.DP);
    var lblTitle = new kony.ui.Label({
        "height": "60%",
        "id": "lblTitle",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0b1500cc0a16e48",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblLocation = new kony.ui.Label({
        "height": "40%",
        "id": "lblLocation",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0d187be48535248",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    FlexContainer0f7cb8d372dce42.add(
    lblTitle, lblLocation);
    FlexContainer0866fa824cb7e4b.add(
    FlexContainer05615ddcd057444, FlexContainer0f7cb8d372dce42);
}
function initializetemplateSegmenCalEvts() {
    FlexContainer01f4b736774bf47 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "20%",
        "id": "FlexContainer01f4b736774bf47",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "skin": "CopyslFbox0a299c54559f748"
    }, {}, {});
    FlexContainer01f4b736774bf47.setDefaultUnit(kony.flex.DP);
    var lblEvtTitle = new kony.ui.Label({
        "height": "34%",
        "id": "lblEvtTitle",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0a3563114d86045",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblEvtStartTime = new kony.ui.Label({
        "height": "33%",
        "id": "lblEvtStartTime",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0f3646b0d2eaf4c",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblEvtEndTime = new kony.ui.Label({
        "height": "33%",
        "id": "lblEvtEndTime",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel01c4655e98c4e46",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    FlexContainer01f4b736774bf47.add(
    lblEvtTitle, lblEvtStartTime, lblEvtEndTime);
}
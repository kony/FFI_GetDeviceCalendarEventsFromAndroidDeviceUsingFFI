function addWidgetsfrmCalendar() {
    frmCalendar.setDefaultUnit(kony.flex.DP);
    var calEvt = new kony.ui.Calendar({
        "calendarIcon": "calbtn.png",
        "dateComponents": [10, 3, 2016, 0, 0, 0],
        "dateFormat": "dd/MM/yyyy",
        "day": 10,
        "formattedDate": "10/03/2016",
        "height": "60%",
        "hour": 0,
        "id": "calEvt",
        "isVisible": true,
        "left": "0dp",
        "minutes": 0,
        "month": 3,
        "onSelection": AS_Calendar_753db2e6b7884ceca137266bd6f8140a,
        "seconds": 0,
        "skin": "slCalendar",
        "top": "0dp",
        "viewType": constants.CALENDAR_VIEW_TYPE_GRID_ONSCREEN,
        "width": "100%",
        "year": 2016
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "dayTextAlignmentInCell": constants.CONTENT_ALIGN_CENTER
    });
    var FlexGroup0c582c33c081f4d = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "40%",
        "id": "FlexGroup0c582c33c081f4d",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "skin": "CopyslFbox08adaace1e4454e",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    FlexGroup0c582c33c081f4d.setDefaultUnit(kony.flex.DP);
    var segCalEvtsForGridView = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "lblEndTime": "",
            "lblLocation": "",
            "lblStartTime": "",
            "lblTitle": ""
        }],
        "groupCells": false,
        "height": "100%",
        "id": "segCalEvtsForGridView",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "pageOffDotImage": "pageOffDot.png",
        "pageOnDotImage": "pageOnDot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "Copyseg0b4d943df4bd243",
        "rowTemplate": FlexContainer0866fa824cb7e4b,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "0dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "FlexContainer05615ddcd057444": "FlexContainer05615ddcd057444",
            "FlexContainer0866fa824cb7e4b": "FlexContainer0866fa824cb7e4b",
            "FlexContainer0f7cb8d372dce42": "FlexContainer0f7cb8d372dce42",
            "lblEndTime": "lblEndTime",
            "lblLocation": "lblLocation",
            "lblStartTime": "lblStartTime",
            "lblTitle": "lblTitle"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexGroup0c582c33c081f4d.add(
    segCalEvtsForGridView);
    frmCalendar.add(
    calEvt, FlexGroup0c582c33c081f4d);
};

function frmCalendarGlobals() {
    frmCalendar = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmCalendar,
        "enabledForIdleTimeout": false,
        "id": "frmCalendar",
        "layoutType": kony.flex.FLOW_VERTICAL,
        "needAppMenu": true,
        "preShow": AS_Form_a4e7a702f26a4bed8d43ee3f783d5506,
        "skin": "slForm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE
    });
};
//actions.js file 
function AS_AppEvents_1651682981e8449c81a9a1f4307bd08c(eventobject) {}
function AS_Button_e9027611aa1346e3b0a5d3cdbd6233ac(eventobject) {
    return invokeFFI.call(this);
}
function AS_Calendar_753db2e6b7884ceca137266bd6f8140a(eventobject, isValidDateSelected) {
    return showEventsForSelectedDate.call(this);
}
function AS_Form_300ef22240354c0c8a80556d0ea6cc5b(eventobject) {
    return invokeFFI.call(this);
}
function AS_Form_a4e7a702f26a4bed8d43ee3f783d5506(eventobject) {
    return showEventsForSelectedDate.call(this);
}
function addWidgetsfrmHome() {
    frmHome.setDefaultUnit(kony.flex.DP);
    var segCalEvts = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "lblEvtEndTime": "Label",
            "lblEvtStartTime": "Label",
            "lblEvtTitle": "Label"
        }, {
            "lblEvtEndTime": "Label",
            "lblEvtStartTime": "Label",
            "lblEvtTitle": "Label"
        }, {
            "lblEvtEndTime": "Label",
            "lblEvtStartTime": "Label",
            "lblEvtTitle": "Label"
        }],
        "groupCells": false,
        "height": "100%",
        "id": "segCalEvts",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "pageOffDotImage": "pageOffDot.png",
        "pageOnDotImage": "pageOnDot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": FlexContainer01f4b736774bf47,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "10%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "FlexContainer01f4b736774bf47": "FlexContainer01f4b736774bf47",
            "lblEvtEndTime": "lblEvtEndTime",
            "lblEvtStartTime": "lblEvtStartTime",
            "lblEvtTitle": "lblEvtTitle"
        },
        "width": "100%"
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Button069c459a5335c48 = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "10%",
        "id": "Button069c459a5335c48",
        "isVisible": true,
        "left": "0dp",
        "onClick": AS_Button_e9027611aa1346e3b0a5d3cdbd6233ac,
        "skin": "slButtonGlossBlue",
        "text": "Refresh Calendar Events",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmHome.add(
    segCalEvts, Button069c459a5335c48);
};

function frmHomeGlobals() {
    frmHome = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmHome,
        "enabledForIdleTimeout": false,
        "id": "frmHome",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "preShow": AS_Form_300ef22240354c0c8a80556d0ea6cc5b,
        "skin": "slForm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE
    });
};